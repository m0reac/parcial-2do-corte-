/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author Usuario
 */
public class accesorios {
    private String producto;
    private String ref_producto;
    private String sexo;
    private String marca;

    public String getProducto() {
        return producto;
    }

    public String getRef_producto() {
        return ref_producto;
    }

    public String getSexo() {
        return sexo;
    }

    public String getMarca() {
        return marca;
    }

    public accesorios(String producto, String ref_producto, String sexo, String marca) {
        this.producto = producto;
        this.ref_producto = ref_producto;
        this.sexo = sexo;
        this.marca = marca;
    }

    
    public String mostrarTab() {
        return "accesorios{" + "producto=" + producto + ", ref_producto=" + ref_producto + ", sexo=" + sexo + ", marca=" + marca + '}';
    }
    
}
