/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class hmckoclss {
    
   private String id_accesorios;
   private String id_balones;
   private String id_calz;
   private String id_hom;
   private String id_kids;
   private String id_muj;
   private String id_ofer;

    public String getId_accesorios() {
        return id_accesorios;
    }

    public String getId_balones() {
        return id_balones;
    }

    public String getId_calz() {
        return id_calz;
    }

    public String getId_hom() {
        return id_hom;
    }

    public String getId_kids() {
        return id_kids;
    }

    public String getId_muj() {
        return id_muj;
    }

    public String getId_ofer() {
        return id_ofer;
    }

    public hmckoclss(String id_accesorios, String id_balones, String id_calz, String id_hom, String id_kids, String id_muj, String id_ofer) {
        this.id_accesorios = id_accesorios;
        this.id_balones = id_balones;
        this.id_calz = id_calz;
        this.id_hom = id_hom;
        this.id_kids = id_kids;
        this.id_muj = id_muj;
        this.id_ofer = id_ofer;
    }

    
    public String mostarTab() {
        return "hmckoclss{" + "id_accesorios=" + id_accesorios + ", id_balones=" + id_balones + ", id_calz=" + id_calz + ", id_hom=" + id_hom + ", id_kids=" + id_kids + ", id_muj=" + id_muj + ", id_ofer=" + id_ofer + '}';
    }

    
    
    
}
