/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class hom {
    
     private String prenda;
    private String talla;
    private String color; 
    private String ref_prenda;
    private String marca;

    public String getPrenda() {
        return prenda;
    }

    public String getTalla() {
        return talla;
    }

    public String getColor() {
        return color;
    }

    public String getRef_prenda() {
        return ref_prenda;
    }

    public String getMarca() {
        return marca;
    }

    public hom(String prenda, String talla, String color, String ref_prenda, String marca) {
        this.prenda = prenda;
        this.talla = talla;
        this.color = color;
        this.ref_prenda = ref_prenda;
        this.marca = marca;
    }

  
    public String mostrarTab() {
        return "calz{" + "prenda=" + prenda + ", talla=" + talla + ", color=" + color + ", ref_prenda=" + ref_prenda + ", marca=" + marca + '}';
    }
    
}
