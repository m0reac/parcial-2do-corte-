/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class ofer {
    
    private String prenda;
    private String balon;
    private String accesorio;
    private String ref_prenda;
    private String marca;
    private String talla;
    private String sexo;
    private String ref_balon;
    private String ref_accesorio;
    private String color;

    public String getPrenda() {
        return prenda;
    }

    public String getBalon() {
        return balon;
    }

    public String getAccesorio() {
        return accesorio;
    }

    public String getRef_prenda() {
        return ref_prenda;
    }

    public String getMarca() {
        return marca;
    }

    public String getTalla() {
        return talla;
    }

    public String getSexo() {
        return sexo;
    }

    public String getRef_balon() {
        return ref_balon;
    }

    public String getRef_accesorio() {
        return ref_accesorio;
    }

    public String getColor() {
        return color;
    }

    public ofer(String prenda, String balon, String accesorio, String ref_prenda, String marca, String talla, String sexo, String ref_balon, String ref_accesorio, String color) {
        this.prenda = prenda;
        this.balon = balon;
        this.accesorio = accesorio;
        this.ref_prenda = ref_prenda;
        this.marca = marca;
        this.talla = talla;
        this.sexo = sexo;
        this.ref_balon = ref_balon;
        this.ref_accesorio = ref_accesorio;
        this.color = color;
    }

    
    public String mostrarTab() {
        return "ofer{" + "prenda=" + prenda + ", balon=" + balon + ", accesorio=" + accesorio + ", ref_prenda=" + ref_prenda + ", marca=" + marca + ", talla=" + talla + ", sexo=" + sexo + ", ref_balon=" + ref_balon + ", ref_accesorio=" + ref_accesorio + ", color=" + color + '}';
    }
    
}
