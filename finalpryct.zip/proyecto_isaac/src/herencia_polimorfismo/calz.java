/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class calz {
    
   private String talla; 
   private String modelo;
   private String marca;
   private String color;
   private String ref_calz;

    public String getTalla() {
        return talla;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public String getRef_calz() {
        return ref_calz;
    }

    public calz(String talla, String modelo, String marca, String color, String ref_calz) {
        this.talla = talla;
        this.modelo = modelo;
        this.marca = marca;
        this.color = color;
        this.ref_calz = ref_calz;
    }

    
    public String mostrarTab() {
        return "calz{" + "talla=" + talla + ", modelo=" + modelo + ", marca=" + marca + ", color=" + color + ", ref_calz=" + ref_calz + '}';
    }
    
    
}
