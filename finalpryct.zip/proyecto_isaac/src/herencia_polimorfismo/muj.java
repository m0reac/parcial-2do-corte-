/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class muj {
    
private String talla;
private String prenda; 
private String color; 
private String ref_prenda;
private String marca;

    public String getTalla() {
        return talla;
    }

    public String getPrenda() {
        return prenda;
    }

    public String getColor() {
        return color;
    }

    public String getRef_prenda() {
        return ref_prenda;
    }

    public String getMarca() {
        return marca;
    }

    public muj(String talla, String prenda, String color, String ref_prenda, String marca) {
        this.talla = talla;
        this.prenda = prenda;
        this.color = color;
        this.ref_prenda = ref_prenda;
        this.marca = marca;
    }

    
    public String mostrarTab() {
        return "muj{" + "talla=" + talla + ", prenda=" + prenda + ", color=" + color + ", ref_prenda=" + ref_prenda + ", marca=" + marca + '}';
    }
                            
    
}
