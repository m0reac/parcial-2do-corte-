/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia_polimorfismo;

/**
 *
 * @author Usuario
 */
public class balones {
    private String deporte;
    private String tamaño;
    private String material;
    private String modelo;

    public String getDeporte() {
        return deporte;
    }

    public String getTamaño() {
        return tamaño;
    }

    public String getMaterial() {
        return material;
    }

    public String getModelo() {
        return modelo;
    }

    public balones(String deporte, String tamaño, String material, String modelo) {
        this.deporte = deporte;
        this.tamaño = tamaño;
        this.material = material;
        this.modelo = modelo;
    }

    
    public String mostrarTab() {
        return "balones{" + "deporte=" + deporte + ", tama\u00f1o=" + tamaño + ", material=" + material + ", modelo=" + modelo + '}';
    }
            
}
